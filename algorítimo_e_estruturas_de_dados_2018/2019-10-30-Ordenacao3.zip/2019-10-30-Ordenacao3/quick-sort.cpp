#include <iostream>
using namespace std;

void mostraVetor(int vet[]){
    for(int i = 0; i < 10; i++)
	{
		cout << vet[i] << ' ';
	}
	cout << endl;
}

void quicksort(int vet[], int esq, int dir)
{
	int i, j, pivo, aux;
	i = esq;
	j = dir-1;
	pivo = vet[(esq + dir) / 2];
	while(i <= j) // n�o se cruzarem
	{
		while(vet[i] < pivo && i < dir)
		{
			i++;
		}
		while(vet[j] > pivo && j > esq)
		{
			j--;
		}
		if(i <= j)
		{
		    // swap
			aux = vet[i];
			vet[i] = vet[j];
			vet[j] = aux;
			i++;
			j--;
		}
	}
	cout << "--------------------------------" << endl;
    cout << "Pivo atual: " << pivo << endl;

	if(j > esq){
        cout << "Recursiva esquerda" << endl;
        mostraVetor(vet);
        cout << "esq: " << esq << "     j+1: " << j+1 << endl;
		quicksort(vet, esq, j+1);
	}
	if(i < dir){
	    cout << "Recursiva direita" << endl;
	    mostraVetor(vet);
        cout << "i: " << i << "     dir: " << dir << endl;
		quicksort(vet, i, dir);
	}
}

int main()
{
	int vetor[10] = {5, 8, 3, 6, 9, 4, 10, 1, 2, 7}; // caso m�dio
	//int vetor[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; // melhor caso
	//int vetor[10] = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1}; // pior caso
	for(int i = 0; i < 10; i++)
	{
		cout << vetor[i] << ' ';
	}
    cout << endl;

	quicksort(vetor, 0, 10);

	for(int i = 0; i < 10; i++)
	{
		cout << vetor[i] << ' ';
	}

	return 0;
}
