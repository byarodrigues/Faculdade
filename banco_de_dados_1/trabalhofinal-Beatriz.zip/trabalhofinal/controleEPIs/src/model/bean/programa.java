package model.bean;

public class programa{

    private int senha;

    public programa(){
    }

    public programa(int senha) {
        this.senha = senha;
    }

    public int getSenha() {
        return senha;
    }

    public void setSenha(int senha) {
        this.senha = senha;
    }

}
