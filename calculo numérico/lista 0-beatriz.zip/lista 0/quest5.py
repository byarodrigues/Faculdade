# -*- coding: utf-8 -*-
"""
Created on Tue Jul 13 19:38:35 2021

@author: Bya
Faça um código que receba um número e responda se o mesmo é par ou ímpar.
"""
n = float(input('Inform the number:'))
if n%2 == 0:
    print('This number is even')
else:
    print('This number is odd ')

