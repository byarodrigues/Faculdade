# -*- coding: utf-8 -*-
"""
Created on Fri Aug  6 00:41:18 2021

@author: Bya
(c) 1010010.0112 para as bases 4, 8, 10, 16
"""


n = str(input('informe o numero: '))
base = 8

n_int = int(n.format(n))
bin_int = ' '
while n_int > 0:
    resto = n_int % base
    bin_int = str(resto) + bin_int
    n_int = n_int
    
n_frac = n - int(n)
bin_frac = ''
for cont in range(base):
    n_frac *=base
    bin_frac += str(int(n_frac))
    n_frac -= int(n_frac)
    if n_frac == 0:
        break
    
print(bin_int + '.' + bin_frac)
