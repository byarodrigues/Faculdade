# -*- coding: utf-8 -*-
"""
Created on Thu Aug  5 13:02:05 2021

@author: Bya
Calcule o erro absoluto e relativo das aproximações:
a) x = 1.00001 e x- = 1
b) x = 100001 e x- = 100000
c) x = 32.65483 e x- = 34.1645
d) x = 5.87135 e x- = 5.87049
"""

