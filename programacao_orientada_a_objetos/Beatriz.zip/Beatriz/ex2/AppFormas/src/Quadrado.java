
public class Quadrado extends Bidimensional {
    
    public Quadrado(){}
    
    public Quadrado(double altura, double largura, double raio){
        super(altura, largura, raio);
    }
     
    public double obterArea(){

        return 27.55;
    }
}
