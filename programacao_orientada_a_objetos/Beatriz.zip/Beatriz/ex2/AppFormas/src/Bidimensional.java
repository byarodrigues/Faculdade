
public class Bidimensional extends Forma {

    public Bidimensional() {
    }
    
    public Bidimensional(double altura, double largura, double raio){
        super(altura, largura, raio);
    }

    public double obterArea() {
        return 6;
    }

}
