#include <iostream>
#include <clocale>
using namespace std;

const int maxTam=50;
struct Tproduto{
    string codigo;
    string nome;
    string preco;
    int quantidade;
};
struct Tlista{
    Tproduto Vetproduto[maxTam];
    int primeiro;
    int ultimo;
};
void criarListaVazia(Tlista &l){
    l.primeiro = 0;
    l.ultimo = l.primeiro;
}
bool estaCheia(Tlista l){
    return l.ultimo >= maxTam;
}
bool estaVazia(Tlista l){
    return l.primeiro == l.ultimo;
}
void inserir(Tlista &l){
    if(estaCheia(l)){
        cout << "lista cheia, nao pode inserir" << endl;
    }
    else
        cout << "codigo:" << endl;
        cin >> l.produto[l.ultimo].codigo >> endl;
        cout << "nome:" << endl;
        cin >> l.produto[l.ultimo].nome >> endl;
        cout << "preco:" << endl;
        cin >> l.produto[l.ultimo].preco >> endl;
        cout << "quantidade em estoque:" << endl;
        cin >> l.produto[l.ultimo].quantidade >> endl;
        l.ultimo ++;
}
void MostrarEstoqB(TLista l){
    if (estaVazia(l)){
        cout << "Nada para mostrar. Lista vazia!" << endl;
    }
    else{
        for (int i=0;i<l.ultimo;i++){
            if (l.produto[i]estoque < 5){
                cout << "produto " << l.produto[i].nome << " com o estoque baixo" << endl;
            }
            else {
                if (i=l.ultimo - 1){
                    cout << "sem produtos acabando" << endl;
                }
                else return 0;
            }
        }
    }
}
int buscarItem(TLista l, int c){
    bool achou = false;
    int pegaitem;
    if (estaVazia(l)){
        return -1;
    }
    else{
        for(int i=l.primeiro;i<l.ultimo;i++){
            if(l.vetItens[i]== c){
                achou = true;
                pegaitem = c;
                break;
            }
        }
        if(achou == true){
            return pegaitem;
        }
        else{
            return -1;
        }
    }
}
int main(){
    setlocale(LC_ALL,"Portuguese");
    TLista l;
    criarListaVazia(l);
    char resp:

    for(int i=0;i< maxTam; i++){
        cout << "deseja inserir um cliente?(S-para sim e N- para nao)" << endl;
        cin >> resp >> endl;
        if (resp == s){
            inserir(l);
        }
        else {
                return 0;
        }
    }
    mostrarEstoqB(l);
    buscariItem(l);

return 0;
}
