void main() {
     int a = 0;
     tmr0l = 0xf7;
     tmr0h = 0xc2;
     t0con = 0b10000110;
     intcon.TMR0IF = 0;
     trisb = 0;
     portb = 0;
     while(1){
          if(intcon.tmr0if == 1){
               tmr0l = 0xf7;
               tmr0h = 0xc2;
               intcon.TMR0IF = 0;
               portb = a;
               a = a*2+1;
          }
     }
}