void main() {
     tmr0l = 0xf7;
     t0con = 0b10000111;
     intcon.TMR0IF = 0;
     trisd = 0;
     portd = 0;
     while(1){
          if(intcon.tmr0if == 1){
               tmr0l = 0xf7;
               intcon.TMR0IF = 0;
               portd = ~portd;
          }
     }
}