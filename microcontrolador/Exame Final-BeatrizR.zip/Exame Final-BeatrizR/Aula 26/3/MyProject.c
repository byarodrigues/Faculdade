// Lcd pinout settings
sbit LCD_RS at RE2_bit;
sbit LCD_EN at RE1_bit;
sbit LCD_D7 at RD7_bit;
sbit LCD_D6 at RD6_bit;
sbit LCD_D5 at RD5_bit;
sbit LCD_D4 at RD4_bit;

// Pin direction
sbit LCD_RS_Direction at TRISE2_bit;
sbit LCD_EN_Direction at TRISE1_bit;
sbit LCD_D7_Direction at TRISD7_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D4_Direction at TRISD4_bit;

void main() {
     int i = 1;
     char txt[6];
     char txt2[6];
     char txt3[6];
     trisb = 255;
     trisa = 0;
     lcd_init();
     lcd_cmd(_lcd_cursor_off);
     tmr0h = 0xc2;
     tmr0l = 0xf7;
     t0con = 0b10000110;
     lcd_out(1,1,"Seja bem vindo! ");
     lcd_out(2,1,"Aperte b0 ou b1 ");
     while(1){
          if(button(&portb,0,1,0)==255){
               trisb = 0;
               portb = 0;
               trisd = 0;
               portd = 255;
               intcon.TMR0IF = 0;
               lcd_out(1,1,"Vezes LED2:     ");
               lcd_out(2,1,"Vezes LED1:     ");
               while(i<17){
                    if(intcon.tmr0if == 1){
                         portb = ~portb;
                         portd = ~portd;
                         intcon.tmr0if = 0;
                         tmr0h = 0xc2;
                         tmr0l = 0xf7;
                         i = i + 1;
                         wordtostr(i/2,txt);
                         lcd_out(1,12,txt);
                         wordtostr((i-1)/2,txt2);
                         lcd_out(2,12,txt2);
                    }
               }

          }
          trisb = 255;
          portb = 0;
          if(button(&portb,1,1,0)==255){
               lcd_out(1,1,"Valor dis1:     ");
               lcd_out(2,1,"                ");
               trisd = 0;
               portd = 0;
               intcon.TMR0IF = 0;
               i = 1;
               porta = 0b00001000;
               while(i<=3){
                    if(intcon.tmr0if == 1){
                    if(i = 1){
                              trisd = 0;
                              portd = 0b00111111;
                              wordtostr(i-1,txt3);
                              lcd_out(1,12,txt3);
                              delay_ms(2000);
                    }
                    if(i = 2){
                              trisd = 0;
                              portd = 0b00000110;
                              wordtostr(i-1,txt3);
                              lcd_out(1,12,txt3);
                              delay_ms(2000);
                    }
                    if(i = 3){
                              trisd = 0;
                              portd = 0b01011011;
                              wordtostr(i-1,txt3);
                              lcd_out(1,12,txt3);
                              delay_ms(2000);
                    }
                    intcon.tmr0if = 0;
                    tmr0h = 0xc2;
                    tmr0l = 0xf7;
                    i = i + 1;
                    }
               }
               trisb = 255;
               portb = 0;
          }
     }
}